// 🧠 Auto-Recovery Core (Phase7.2)
import { exec } from 'child_process';
import fs from 'fs';

const LOG_PATH = './SigmaMemory/logs/auto_recovery.log';
const WATCH_PATHS = ['./SigmaMemory/data', './SigmaMemory/instructions', './SigmaMemory/logs'];

function log(msg) {
  const time = new Date().toISOString();
  fs.appendFileSync(LOG_PATH, );
}

function restart() {
  log('🔁 Restart triggered');
  exec('bash run.sh', (err, stdout, stderr) => {
    if (err) log('Error restarting: ' + err);
    else log('Restart successful');
  });
}

function monitor() {
  WATCH_PATHS.forEach(path => {
    fs.watch(path, (event, filename) => {
      if (event === 'change' || event === 'rename') {
        log('Change detected: ' + filename);
        restart();
      }
    });
  });
  log('🧩 Auto-Recovery monitoring initialized');
}

monitor();
import { record } from './logger.mjs';
record('🔍 Change detection activated', 'Monitoring SigmaMemory directories');
import { diagnose } from './diagnostic.mjs';
process.on('uncaughtException', err => {
  diagnose(err.message);
  console.error('Self-Diagnostic captured:', err.message);
});
import { chronoMonitor } from './chrono_monitor.mjs';
setInterval(() => {
  const simulatedValue = Math.random() > 0.05 ? 1 : -1; // 5% chance of anomaly
  chronoMonitor(simulatedValue);
}, 10000);
